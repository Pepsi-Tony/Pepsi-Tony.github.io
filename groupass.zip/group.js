function ms1(){
    document.getElementById('film1').src = 'bf1.webp'}

function ms2(){
    document.getElementById('film2').src = 'bf2.webp'}

function ms3(){
    document.getElementById('film3').src = 'bf3.webp'}

function ms4(){
    document.getElementById('film4').src = 'bf4.webp'}

function ms5(){
    document.getElementById('film5').src = 'bf5.webp'}

function ms6(){
    document.getElementById('film6').src = 'bf6.webp'}

function ms7(){
    document.getElementById('film1').src = 'film1.jpg'}

function ms8(){
    document.getElementById('film2').src = 'film2.jpg'}

function ms9(){
    document.getElementById('film3').src = 'film3.jpg'}

function ms10(){
    document.getElementById('film4').src = 'film4.jpg'}

function ms11(){
    document.getElementById('film5').src = 'film5.jpg'}

function ms12(){
    document.getElementById('film6').src = 'film6.jpg'}

function bv1(){
    document.getElementById('v1').src = 'bv2.webp'}
function bv2(){
    document.getElementById('v2').src = 'bv1.webp'}
function bv3(){
    document.getElementById('v3').src = 'bv3.webp'}
function bv4(){
    document.getElementById('v4').src = 'bv4.webp'}
function bv5(){
    document.getElementById('v5').src = 'bv5.webp'}
function bv6(){
    document.getElementById('v6').src = 'bv6.webp'}
function bi1(){
    document.getElementById('v1').src = 'bv1.jpg'}
function bi2(){
    document.getElementById('v2').src = 'bv2.jpg'}
function bi3(){
    document.getElementById('v3').src = 'bv3.jpg'}
function bi4(){
    document.getElementById('v4').src = 'bv4.jpg'}
function bi5(){
    document.getElementById('v5').src = 'bv5.jpg'}
function bi6(){
    document.getElementById('v6').src = 'bv6.jpg'}

function ndecoration1(){
    document.getElementsByClassName('fbp')[0].style.textDecoration = 'underline'}
function ndecoration2(){
    document.getElementsByClassName('fbp')[1].style.textDecoration = 'underline'}
function ndecoration3(){
    document.getElementsByClassName('fbp')[2].style.textDecoration = 'underline'}
function ndecoration4(){
    document.getElementsByClassName('fbp')[3].style.textDecoration = 'underline'}
function ndecoration5(){
    document.getElementsByClassName('fbp')[4].style.textDecoration = 'underline'}
function ndecoration6(){
    document.getElementsByClassName('fbp')[5].style.textDecoration = 'underline'}
function ndecoration7(){
    document.getElementsByClassName('fbp')[6].style.textDecoration = 'underline'}
function ndecoration8(){
    document.getElementsByClassName('fbp')[7].style.textDecoration = 'underline'}
function ndecoration9(){
    document.getElementsByClassName('fbp')[8].style.textDecoration = 'underline'}
function ndecoration10(){
    document.getElementsByClassName('fbp')[9].style.textDecoration = 'underline'}
function ndecoration11(){
    document.getElementsByClassName('fbp')[10].style.textDecoration = 'underline'}
function ndecoration12(){
    document.getElementsByClassName('fbp')[11].style.textDecoration = 'underline'}
function ndecoration13(){
    document.getElementsByClassName('fbp')[12].style.textDecoration = 'underline'}
function ndecoration14(){
    document.getElementsByClassName('fbp')[13].style.textDecoration = 'underline'}
function ndecoration15(){
    document.getElementsByClassName('fbp')[14].style.textDecoration = 'underline'}
function ndecoration16(){
    document.getElementsByClassName('fbp')[15].style.textDecoration = 'underline'}
function ndecoration17(){
    document.getElementsByClassName('fbp')[16].style.textDecoration = 'underline'}
function ndecoration18(){
    document.getElementsByClassName('fbp')[17].style.textDecoration = 'underline'}
function ndecoration19(){
    document.getElementsByClassName('fbp')[18].style.textDecoration = 'underline'}
function ndecoration20(){
    document.getElementsByClassName('fbp')[19].style.textDecoration = 'underline'}
function ndecoration21(){
    document.getElementsByClassName('fbp')[20].style.textDecoration = 'underline'}
function ndecoration22(){
    document.getElementsByClassName('fbp')[21].style.textDecoration = 'underline'}
function ndecoration23(){
    document.getElementsByClassName('fbp')[22].style.textDecoration = 'underline'}
function ndecoration24(){
    document.getElementsByClassName('fbp')[23].style.textDecoration = 'underline'}
function ndecoration25(){
    document.getElementsByClassName('fbp')[24].style.textDecoration = 'underline'}
function ndecoration26(){
    document.getElementsByClassName('fbp')[25].style.textDecoration = 'underline'}
function ndecoration27(){
    document.getElementsByClassName('fbp')[26].style.textDecoration = 'underline'}
function ndecoration28(){
    document.getElementsByClassName('fbp')[27].style.textDecoration = 'underline'}
function ndecoration29(){
    document.getElementsByClassName('fbp')[28].style.textDecoration = 'underline'}
function ndecoration30(){
    document.getElementsByClassName('fbp')[29].style.textDecoration = 'underline'}
function ndecoration31(){
    document.getElementsByClassName('fbp')[30].style.textDecoration = 'underline'}
function ndecoration32(){
    document.getElementsByClassName('fbp')[31].style.textDecoration = 'underline'}
function ndecoration33(){
    document.getElementsByClassName('fbp')[32].style.textDecoration = 'underline'}
function ndecoration34(){
    document.getElementsByClassName('fbp')[33].style.textDecoration = 'underline'}
function ndecoration35(){
    document.getElementsByClassName('fbp')[34].style.textDecoration = 'underline'}
function ndecoration36(){
    document.getElementsByClassName('fbp')[35].style.textDecoration = 'underline'}
function ndecoration37(){
    document.getElementsByClassName('fbp')[36].style.textDecoration = 'underline'}
function decoration1(){
    document.getElementsByClassName('fbp')[0].style.textDecoration = 'none'}
function decoration2(){
    document.getElementsByClassName('fbp')[1].style.textDecoration = 'none'}
function decoration3(){
    document.getElementsByClassName('fbp')[2].style.textDecoration = 'none'}
function decoration4(){
    document.getElementsByClassName('fbp')[3].style.textDecoration = 'none'}
function decoration5(){
    document.getElementsByClassName('fbp')[4].style.textDecoration = 'none'}
function decoration6(){
    document.getElementsByClassName('fbp')[5].style.textDecoration = 'none'}
function decoration7(){
    document.getElementsByClassName('fbp')[6].style.textDecoration = 'none'}
function decoration8(){
    document.getElementsByClassName('fbp')[7].style.textDecoration = 'none'}
function decoration9(){
    document.getElementsByClassName('fbp')[8].style.textDecoration = 'none'}
function decoration10(){
    document.getElementsByClassName('fbp')[9].style.textDecoration = 'none'}
function decoration11(){
    document.getElementsByClassName('fbp')[10].style.textDecoration = 'none'}
function decoration12(){
    document.getElementsByClassName('fbp')[11].style.textDecoration = 'none'}
function decoration13(){
    document.getElementsByClassName('fbp')[12].style.textDecoration = 'none'}
function decoration14(){
    document.getElementsByClassName('fbp')[13].style.textDecoration = 'none'}
function decoration15(){
    document.getElementsByClassName('fbp')[14].style.textDecoration = 'none'}
function decoration16(){
    document.getElementsByClassName('fbp')[15].style.textDecoration = 'none'}
function decoration17(){
    document.getElementsByClassName('fbp')[16].style.textDecoration = 'none'}
function decoration18(){
    document.getElementsByClassName('fbp')[17].style.textDecoration = 'none'}
function decoration19(){
    document.getElementsByClassName('fbp')[18].style.textDecoration = 'none'}
function decoration20(){
    document.getElementsByClassName('fbp')[19].style.textDecoration = 'none'}
function decoration21(){
    document.getElementsByClassName('fbp')[20].style.textDecoration = 'none'}
function decoration22(){
    document.getElementsByClassName('fbp')[21].style.textDecoration = 'none'}
function decoration23(){
    document.getElementsByClassName('fbp')[22].style.textDecoration = 'none'}
function decoration24(){
    document.getElementsByClassName('fbp')[23].style.textDecoration = 'none'}
function decoration25(){
    document.getElementsByClassName('fbp')[24].style.textDecoration = 'none'}
function decoration26(){
    document.getElementsByClassName('fbp')[25].style.textDecoration = 'none'}
function decoration27(){
    document.getElementsByClassName('fbp')[26].style.textDecoration = 'none'}
function decoration28(){
    document.getElementsByClassName('fbp')[27].style.textDecoration = 'none'}
function decoration29(){
    document.getElementsByClassName('fbp')[28].style.textDecoration = 'none'}
function decoration30(){
    document.getElementsByClassName('fbp')[29].style.textDecoration = 'none'}
function decoration31(){
    document.getElementsByClassName('fbp')[30].style.textDecoration = 'none'}
function decoration32(){
    document.getElementsByClassName('fbp')[31].style.textDecoration = 'none'}
function decoration33(){
    document.getElementsByClassName('fbp')[32].style.textDecoration = 'none'}
function decoration34(){
    document.getElementsByClassName('fbp')[33].style.textDecoration = 'none'}
function decoration35(){
    document.getElementsByClassName('fbp')[34].style.textDecoration = 'none'}
function decoration36(){
    document.getElementsByClassName('fbp')[35].style.textDecoration = 'none'}
function decoration37(){
    document.getElementsByClassName('fbp')[36].style.textDecoration = 'none'}


function fv1(){
    document.getElementById('fv1').src = 'fv1.webp'}
function fv2(){
    document.getElementById('fv2').src = 'fv2.webp'}
function fv3(){
    document.getElementById('fv3').src = 'fv3.webp'}
function fv4(){
    document.getElementById('fv4').src = 'fv4.webp'}
function fv5(){
    document.getElementById('fv5').src = 'fv5.webp'}
function fv6(){
    document.getElementById('fv6').src = 'fv6.webp'}
function fi1(){
    document.getElementById('fv1').src = 'fi1.jpg'}
function fi2(){
    document.getElementById('fv2').src = 'fi2.jpg'}
function fi3(){
    document.getElementById('fv3').src = 'fi3.jpg'}
function fi4(){
    document.getElementById('fv4').src = 'fi4.jpg'}
function fi5(){
    document.getElementById('fv5').src = 'fi5.jpg'}
function fi6(){
    document.getElementById('fv6').src = 'fi6.jpg'}

function cff1(){
    var cf = document.getElementById('ff1').style;
    cf.color = 'darkgoldenrod';
}

function cfb1(){
    var cf = document.getElementById('ff1').style;
    cf.color = 'black';
}

function cff2(){
    var cf = document.getElementById('ff2').style;
    cf.color = 'darkgoldenrod';
}

function cfb2(){
    var cf = document.getElementById('ff2').style;
    cf.color = 'black';
}

function cff3(){
    var cf = document.getElementById('ff3').style;
    cf.color = 'darkgoldenrod';
}

function cfb3(){
    var cf = document.getElementById('ff3').style;
    cf.color = 'black';
}

function cff4(){
    var cf = document.getElementById('ff4').style;
    cf.color = 'darkgoldenrod'
}

function cfb4(){
    var cf = document.getElementById('ff4').style;
    cf.color = 'black'
}

function cff5(){
    var cf = document.getElementById('ff5').style;
    cf.color = 'darkgoldenrod';
}

function cfb5(){
    var cf = document.getElementById('ff5').style;
    cf.color = 'black';
}

function submitq(){
    var sb = document.getElementById('submit').style;
    sb.display = 'none';
    var asb = document.getElementById('aftersb');
    asb.innerHTML = 'Thanks for your suggestions!';
}

function ques(){
    var qu = document.getElementById('submit').style;
    qu.display = 'inherit';
    var qn = document.getElementById('queslink').style;
    qn.display = 'none';
}

function quesm(){
    var qnn = document.getElementById('queslink').style;
    qnn.color = 'darkgoldenrod';
    qnn.textShadow = 'lightblue 5px 4px 7px';
}

function quesm1(){
    var qna = document.getElementById('queslink').style;
    qna.color = 'lightgoldenrodyellow';
    qna.textShadow = 'darkgreen 5px 4px 7px';
}


var canvas = document.getElementById("canvas");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
var ctx = canvas.getContext("2d");
var particlesArray = [];
var count = parseInt(canvas.height / 100 * canvas.width / 100);
class Particle {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.directionY = 0.5 - Math.random();
        this.directionX = 0.5 - Math.random();
    }
    update() {
        this.y += this.directionY;
        this.x += this.directionX;
    }
    draw() {
        ctx.beginPath();
        ctx.arc(this.x, this.y, 2, 0, Math.PI * 2);
        ctx.fillStyle = "white";
        ctx.fill();
    }
}

function createParticle() {
    var x = Math.random() * canvas.width;
    var y = Math.random() * canvas.height;
    particlesArray.push(new Particle(x, y));
}

function handleParticle() {
    for (var i = 0; i < particlesArray.length; i++) {
        var particle = particlesArray[i];
        particle.update();
        particle.draw();
        if (particle.x < 0 || particle.x > canvas.width || particle.y < 0 || particle.y > canvas.height) {
            particlesArray.splice(i, 1);
        }
        for (var j = i; j < particlesArray.length; j++) {
            dx = particlesArray[i].x - particlesArray[j].x;
            dy = particlesArray[i].y - particlesArray[j].y;
            long = Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2));
            if (long < 100) {
                ctx.beginPath();
                ctx.strokeStyle = "rgba(255,255,255," + (1 - long / 200) + ")";
                ctx.moveTo(particlesArray[i].x, particlesArray[i].y);
                ctx.lineTo(particlesArray[j].x, particlesArray[j].y);
                ctx.lineWidth = 1;
                ctx.stroke();
            }
        }
    }
}

function draw() {
    ctx.clearRect(1, 1, canvas.width, canvas.height);
    if (particlesArray.length < count) {
        createParticle();
    }
    handleParticle();
}
setInterval(() => {
    draw(), 1;
})

